#include <stdio.h>
#include <stdlib.h>

#define ORDER 4

typedef struct BTreeNode {
    int keys[ORDER - 1];
    struct BTreeNode *children[ORDER];
    int numKeys;
    int isLeaf;
} BTreeNode;

BTreeNode *createNode(int isLeaf) {
    BTreeNode *node = (BTreeNode *)malloc(sizeof(BTreeNode));
    node->isLeaf = isLeaf;
    node->numKeys = 0;
    for (int i = 0; i < ORDER; i++) {
        node->children[i] = NULL;
    }
    return node;
}

void splitChild(BTreeNode *parent, int i, BTreeNode *child) {
    BTreeNode *newChild = createNode(child->isLeaf);
    newChild->numKeys = ORDER / 2 - 1;

    for (int j = 0; j < ORDER / 2 - 1; j++) {
        newChild->keys[j] = child->keys[j + ORDER / 2];
    }

    if (!child->isLeaf) {
        for (int j = 0; j < ORDER / 2; j++) {
            newChild->children[j] = child->children[j + ORDER / 2];
        }
    }

    child->numKeys = ORDER / 2 - 1;

    for (int j = parent->numKeys; j >= i + 1; j--) {
        parent->children[j + 1] = parent->children[j];
    }

    parent->children[i + 1] = newChild;

    for (int j = parent->numKeys - 1; j >= i; j--) {
        parent->keys[j + 1] = parent->keys[j];
    }

    parent->keys[i] = child->keys[ORDER / 2 - 1];
    parent->numKeys++;
}

void insertNonFull(BTreeNode *node, int key) {
    int i = node->numKeys - 1;

    if (node->isLeaf) {
        while (i >= 0 && key < node->keys[i]) {
            node->keys[i + 1] = node->keys[i];
            i--;
        }
        node->keys[i + 1] = key;
        node->numKeys++;
    } else {
        while (i >= 0 && key < node->keys[i]) {
            i--;
        }
        i++;
        if (node->children[i]->numKeys == ORDER - 1) {
            splitChild(node, i, node->children[i]);
            if (key > node->keys[i]) {
                i++;
            }
        }
        insertNonFull(node->children[i], key);
    }
}

void insert(BTreeNode **root, int key) {
    BTreeNode *r = *root;
    if (r->numKeys == ORDER - 1) {
        BTreeNode *s = createNode(0);
        s->children[0] = r;
        splitChild(s, 0, r);
        insertNonFull(s, key);
        *root = s;
    } else {
        insertNonFull(r, key);
    }
}

void printTree(BTreeNode *root, int level) {
    if (root != NULL) {
        printf("Level %d: ", level);
        for (int i = 0; i < root->numKeys; i++) {
            printf("%d ", root->keys[i]);
        }
        printf("\n");
        for (int i = 0; i <= root->numKeys; i++) {
            printTree(root->children[i], level + 1);
        }
    }
}

void deleteKey(BTreeNode *root, int key);
void deleteFromNode(BTreeNode *node, int key);

void delete(BTreeNode **root, int key) {
    deleteKey(*root, key);
    if ((*root)->numKeys == 0) {
        BTreeNode *tmp = *root;
        if ((*root)->isLeaf) {
            *root = NULL;
        } else {
            *root = (*root)->children[0];
        }
        free(tmp);
    }
}

void deleteKey(BTreeNode *root, int key) {
    deleteFromNode(root, key);
}

void deleteFromNode(BTreeNode *node, int key) {
    int idx = 0;
    while (idx < node->numKeys && node->keys[idx] < key) {
        idx++;
    }

    if (idx < node->numKeys && node->keys[idx] == key) {
        if (node->isLeaf) {
            for (int i = idx + 1; i < node->numKeys; i++) {
                node->keys[i - 1] = node->keys[i];
            }
            node->numKeys--;
        } else {
            BTreeNode *pred = node->children[idx];
            while (!pred->isLeaf) {
                pred = pred->children[pred->numKeys];
            }
            int predKey = pred->keys[pred->numKeys - 1];
            deleteFromNode(node->children[idx], predKey);
            node->keys[idx] = predKey;
        }
    } else {
        if (node->isLeaf) {
            printf("The key %d is not present in the tree\n", key);
            return;
        }

        int flag = (idx == node->numKeys);

        if (node->children[idx]->numKeys < ORDER / 2) {
            if (idx != 0 && node->children[idx - 1]->numKeys >= ORDER / 2) {
                BTreeNode *child = node->children[idx];
                BTreeNode *sibling = node->children[idx - 1];

                for (int i = child->numKeys - 1; i >= 0; i--) {
                    child->keys[i + 1] = child->keys[i];
                }

                if (!child->isLeaf) {
                    for (int i = child->numKeys; i >= 0; i--) {
                        child->children[i + 1] = child->children[i];
                    }
                }

                child->keys[0] = node->keys[idx - 1];

                if (!child->isLeaf) {
                    child->children[0] = sibling->children[sibling->numKeys];
                }

                node->keys[idx - 1] = sibling->keys[sibling->numKeys - 1];

                child->numKeys += 1;
                sibling->numKeys -= 1;
            } else if (idx != node->numKeys && node->children[idx + 1]->numKeys >= ORDER / 2) {
                BTreeNode *child = node->children[idx];
                BTreeNode *sibling = node->children[idx + 1];

                child->keys[child->numKeys] = node->keys[idx];

                if (!child->isLeaf) {
                    child->children[child->numKeys + 1] = sibling->children[0];
                }

                node->keys[idx] = sibling->keys[0];

                for (int i = 1; i < sibling->numKeys; i++) {
                    sibling->keys[i - 1] = sibling->keys[i];
                }

                if (!sibling->isLeaf) {
                    for (int i = 1; i <= sibling->numKeys; i++) {
                        sibling->children[i - 1] = sibling->children[i];
                    }
                }

                child->numKeys += 1;
                sibling->numKeys -= 1;
            } else {
                if (idx != node->numKeys) {
                    BTreeNode *child = node->children[idx];
                    BTreeNode *sibling = node->children[idx + 1];

                    child->keys[child->numKeys] = node->keys[idx];

                    for (int i = 0; i < sibling->numKeys; i++) {
                        child->keys[child->numKeys + 1 + i] = sibling->keys[i];
                    }

                    if (!child->isLeaf) {
                        for (int i = 0; i <= sibling->numKeys; i++) {
                            child->children[child->numKeys + 1 + i] = sibling->children[i];
                        }
                    }

                    for (int i = idx + 1; i < node->numKeys; i++) {
                        node->keys[i - 1] = node->keys[i];
                    }

                    for (int i = idx + 2; i <= node->numKeys; i++) {
                        node->children[i - 1] = node->children[i];
                    }

                    child->numKeys += sibling->numKeys + 1;
                    node->numKeys--;

                    free(sibling);
                } else {
                    BTreeNode *child = node->children[idx - 1];
                    BTreeNode *sibling = node->children[idx];

                    child->keys[child->numKeys] = node->keys[idx - 1];

                    for (int i = 0; i < sibling->numKeys; i++) {
                        child->keys[child->numKeys + 1 + i] = sibling->keys[i];
                    }

                    if (!child->isLeaf) {
                        for (int i = 0; i <= sibling->numKeys; i++) {
                            child->children[child->numKeys + 1 + i] = sibling->children[i];
                        }
                    }

                    for (int i = idx; i < node->numKeys; i++) {
                        node->keys[i - 1] = node->keys[i];
                    }

                    for (int i = idx + 1; i <= node->numKeys; i++) {
                        node->children[i - 1] = node->children[i];
                    }

                    child->numKeys += sibling->numKeys + 1;
                    node->numKeys--;

                    free(sibling);
                }
            }
        }

        if (flag && idx > node->numKeys) {
            deleteFromNode(node->children[idx - 1], key);
        } else {
            deleteFromNode(node->children[idx], key);
        }
    }
}

int main() {
    BTreeNode *root = createNode(1);

    int keysToInsert[] = {5, 3, 21, 9, 13, 22, 7, 10, 11, 14, 8, 16, 25, 28, 15};
    int numKeysToInsert = sizeof(keysToInsert) / sizeof(keysToInsert[0]);

    for (int i = 0; i < numKeysToInsert; i++) {
        insert(&root, keysToInsert[i]);
    }

    printf("B-Tree after insertions:\n");
    printTree(root, 0);

    int keysToDelete[] = {28, 21, 5, 7, 9, 8, 10, 22};
    int numKeysToDelete = sizeof(keysToDelete) / sizeof(keysToDelete[0]);

    for (int i = 0; i < numKeysToDelete; i++) {
        delete(&root, keysToDelete[i]);
        printf("B-Tree after deleting %d:\n", keysToDelete[i]);
        printTree(root, 0);
    }

    return 0;
}
